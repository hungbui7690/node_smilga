require("./06a_mind_grenade");

/* 
  ! có thể thấy khi chạy thằng này lên thì hàm bên thằng 06a đã chạy, và hàm vẫn có thể access tới 2 biến num1 và num2 trong khi chúng ta ko hề export chúng 
*/
