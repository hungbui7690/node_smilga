const sayHi = (name) => {
  console.log(`Hello there, ${name}`);
};

// * Chỉ có 1 biến nên không cần bỏ vào object
module.exports = sayHi;
