const sayHi = (name) => {
  console.log(`Hello there, ${name}`);
};

module.exports = sayHi;
