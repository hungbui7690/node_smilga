const sayHi = require("./05b_utils");
const data = require("./05a_person");

console.log(data);

/////////////////////////////////////
console.log("========= 1 =========");
/////////////////////////////////////

sayHi("Alan");
