const num1 = 5;
const num2 = 10;

function add() {
  console.log(`The sum is ${num1 + num2}`);
}

add();

module.exports.add = add;
